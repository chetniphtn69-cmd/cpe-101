let currentValue = '0';
let previousValue = '';
let operator = null;
let shouldResetScreen = false;

const currentDisplay = document.getElementById('currentDisplay');
const prevDisplay = document.getElementById('prevDisplay');

function updateDisplay() {
  currentDisplay.textContent = currentValue;
  prevDisplay.textContent = previousValue + ' ' + (operator || '');
  adjustFontSize();
}

function adjustFontSize() {
  const length = currentValue.length;
  let size;
  if (length <= 7) size = 40;
  else if (length <= 10) size = 32;
  else if (length <= 13) size = 24;
  else size = 18;
  currentDisplay.style.fontSize = size + 'px';
}

function appendNumber(num) {
  if (shouldResetScreen) {
    currentValue = '0';
    shouldResetScreen = false;
  }
  if (num === '.' && currentValue.includes('.')) return;
  currentValue = currentValue === '0' && num !== '.' ? num : currentValue + num;
  updateDisplay();
}

function chooseOperator(op) {
  if (operator !== null) calculate();
  previousValue = currentValue;
  operator = op;
  shouldResetScreen = true;
  updateDisplay();
}

function calculate() {
  if (operator === null || shouldResetScreen) return;
  const prev = parseFloat(previousValue);
  const curr = parseFloat(currentValue);
  let result;

  switch (operator) {
    case '+': result = prev + curr; break;
    case '-': result = prev - curr; break;
    case '×': result = prev * curr; break;
    case '÷': result = curr === 0 ? 'Error' : prev / curr; break;
    default: return;
  }

  currentValue = result.toString();
  operator = null;
  previousValue = '';
  shouldResetScreen = true;
  updateDisplay();
}

function clearAll() {
  currentValue = '0';
  previousValue = '';
  operator = null;
  updateDisplay();
}

function toggleSign() {
  currentValue = (parseFloat(currentValue) * -1).toString();
  updateDisplay();
}

function percent() {
  currentValue = (parseFloat(currentValue) / 100).toString();
  updateDisplay();
}
